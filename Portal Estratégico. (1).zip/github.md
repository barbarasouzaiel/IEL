repo: barbarasouzaiel/IEL
branch: main

## Last sync
date: 2026-09-28T20:25:21Z

### Updated in this project
- Repositório conectado; contém um index.html publicado (versão anterior do portal)
- Nova versão gerada localmente em index.html (navegação executiva, logo branca centralizada, correções de contagem)

## Screen map
| Tela do projeto | Arquivo no repositório |
|---|---|
| Portal Estratégico IEL.dc.html (bundle → index.html) | index.html |
