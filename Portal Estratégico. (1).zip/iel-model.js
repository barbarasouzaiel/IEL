// Derives navigable indices (counts, responsáveis, search, tree rows) from the raw hierarchy.
function splitResp(s) {
  if (!s) return [];
  return s.split(/;|\n|\//).map(x => {
    let t = x.trim();
    // strip range prefixes like "2.1.1 a 2.1.4 " or "7.1.3  a 7.1.6 "
    t = t.replace(/^\d+(\.\d+)*\s+a\s+\d+(\.\d+)*\.?\s*/i, '');
    // strip a single leading code like "1.1.2 "
    t = t.replace(/^\d+(\.\d+)*\.?\s*/, '');
    // strip leftover range tail like "a 2.1.4 " (from "2.1.1 a 2.1.4 Nome" already partly stripped)
    t = t.replace(/^a\s+\d+(\.\d+)*\.?\s*/i, '');
    // normalize trailing punctuation/whitespace so "Nome." merges with "Nome"
    t = t.replace(/[.\s]+$/, '').trim();
    // collapse internal double spaces (e.g. "Gabriella  Godoy") so name variants merge
    t = t.replace(/\s{2,}/g, ' ');
    return t;
  }).filter(Boolean);
}

function buildModel(hierarchy) {
  const krs = [];
  const iniciativas = [];
  const respIndex = {}; // name -> record
  const eixosMeta = [];
  const resultados = []; // Resultado Estratégico entries, sourced directly from column H per KR

  hierarchy.forEach((eixo, ei) => {
    const eixoId = `e${ei}`;
    const eixoRec = { id: eixoId, nome: eixo.nome, comites: [] };
    eixosMeta.push(eixoRec);
    eixo.comites.forEach((comite, ci) => {
      const comiteId = `${eixoId}.c${ci}`;
      const comiteRec = { id: comiteId, nome: comite.nome, eixo: eixoRec.nome, eixoId, objetivos: [] };
      eixoRec.comites.push(comiteRec);
      comite.objetivos.forEach((obj, oi) => {
        const objId = `${comiteId}.o${oi}`;
        const objRec = { id: objId, nome: obj.nome, comite: comiteRec.nome, comiteId, eixo: eixoRec.nome, eixoId, krs: [] };
        comiteRec.objetivos.push(objRec);
        obj.krs.forEach((kr, ki) => {
          const krId = `${objId}.k${ki}`;
          const codeMatch = kr.label.match(/^(KR\s*[\d.]+|[\d.]+)/i);
          const krRec = {
            id: krId,
            label: kr.label,
            codigo: codeMatch ? codeMatch[1].replace(/\s+/g, ' ').trim() : kr.label.slice(0, 12),
            metaSistemica: kr.metaSistemica,
            resultadoAnteriorRaw: kr.resultadoAnteriorRaw,
            raw: kr.raw,
            objetivo: objRec.nome, objId,
            comite: comiteRec.nome, comiteId,
            eixo: eixoRec.nome, eixoId,
            iniciativas: [],
          };
          objRec.krs.push(krRec);
          krs.push(krRec);
          (kr.resultadosColH || []).forEach((texto, ri) => {
            resultados.push({
              id: `${krId}.res${ri}`, texto,
              krId, krLabel: krRec.label, objId, objetivo: objRec.nome,
              comiteId, comite: comiteRec.nome, eixoId, eixo: eixoRec.nome,
            });
          });
          kr.iniciativas.forEach((it, ii) => {
            const itId = `${krId}.i${ii}`;
            const responsaveis = splitResp(it.responsavel);
            const itRec = {
              id: itId, codigo: it.codigo, descricao: it.descricao,
              resultado: it.resultado, metaIndividual: it.metaIndividual,
              responsavelRaw: it.responsavel, responsaveis,
              krId, krLabel: krRec.label, objId, objetivo: objRec.nome,
              comiteId, comite: comiteRec.nome, eixoId, eixo: eixoRec.nome,
            };
            krRec.iniciativas.push(itRec);
            iniciativas.push(itRec);
            responsaveis.forEach(name => {
              if (!respIndex[name]) respIndex[name] = { nome: name, iniciativas: [], krs: new Set(), objetivos: new Set(), comites: new Set(), eixos: new Set() };
              const r = respIndex[name];
              r.iniciativas.push(itRec);
              r.krs.add(krRec.id);
              r.objetivos.add(objRec.id);
              r.comites.add(comiteRec.id);
              r.eixos.add(eixoRec.id);
            });
          });
        });
      });
    });
  });

  const responsaveis = Object.values(respIndex).map(r => ({
    ...r,
    krIds: Array.from(r.krs), objIds: Array.from(r.objetivos), comiteIds: Array.from(r.comites), eixoIds: Array.from(r.eixos),
  })).sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));

  const counts = {
    eixos: eixosMeta.length,
    comites: new Set(krs.map(k => k.comiteId)).size,
    objetivos: new Set(krs.map(k => k.objId)).size,
    krs: krs.length,
    iniciativas: iniciativas.length,
    resultados: resultados.length,
    metas: iniciativas.filter(i => i.metaIndividual).length,
    responsaveis: responsaveis.length,
  };

  // search index
  const searchItems = [];
  eixosMeta.forEach(e => searchItems.push({ type: 'Eixo', label: e.nome, breadcrumb: e.nome, id: e.id, blob: e.nome }));
  eixosMeta.forEach(e => e.comites.forEach(c => searchItems.push({ type: 'Comitê', label: c.nome, breadcrumb: `${e.nome} › ${c.nome}`, id: c.id, blob: c.nome })));
  krs.forEach(k => {
    searchItems.push({ type: 'Objetivo Estratégico', label: k.objetivo, breadcrumb: `${k.eixo} › ${k.comite}`, id: k.objId, blob: k.objetivo });
    searchItems.push({ type: 'KR', label: k.label, breadcrumb: `${k.eixo} › ${k.comite} › ${k.objetivo}`, id: k.id, blob: [k.label, k.metaSistemica].filter(Boolean).join(' ') });
  });
  iniciativas.forEach(it => {
    searchItems.push({ type: 'Iniciativa', label: it.descricao || it.codigo || 'Iniciativa', breadcrumb: `${it.eixo} › ${it.comite} › ${it.krLabel}`, id: it.krId, blob: [it.descricao, it.resultado, it.metaIndividual].filter(Boolean).join(' ') });
  });
  responsaveis.forEach(r => searchItems.push({ type: 'Responsável', label: r.nome, breadcrumb: `${r.iniciativas.length} entregas`, id: r.nome, blob: r.nome }));
  // dedupe objetivos (pushed multiple times per kr)
  const seenObj = new Set();
  const dedupedSearch = searchItems.filter(s => {
    if (s.type !== 'Objetivo Estratégico') return true;
    if (seenObj.has(s.id)) return false;
    seenObj.add(s.id);
    return true;
  });

  return { eixosMeta, krs, iniciativas, responsaveis, resultados, counts, searchItems: dedupedSearch };
}

// Flattens the tree into visible rows given a set of expanded node ids and active filters.
function flattenTree(eixosMeta, expanded, filters) {
  const rows = [];
  const kw = (filters.keyword || '').toLowerCase().trim();
  function matchesKw(text) { return !kw || (text || '').toLowerCase().includes(kw); }

  function krPassesFilters(kr) {
    if (filters.responsavel) {
      const names = new Set();
      kr.iniciativas.forEach(it => it.responsaveis.forEach(n => names.add(n)));
      if (!names.has(filters.responsavel)) return false;
    }
    if (kw) {
      const blob = [kr.label, kr.metaSistemica, ...kr.iniciativas.map(i => `${i.descricao} ${i.resultado} ${i.metaIndividual} ${i.responsavelRaw}`)].join(' ');
      if (!matchesKw(blob)) return false;
    }
    return true;
  }

  eixosMeta.forEach(eixo => {
    if (filters.eixoId && filters.eixoId !== eixo.id) return;
    const comitesVisible = eixo.comites.filter(c => !filters.comiteId || filters.comiteId === c.id);
    const eixoHasMatch = comitesVisible.some(c => c.objetivos.some(o => (!filters.objId || filters.objId === o.id) && o.krs.some(krPassesFilters)));
    if ((filters.comiteId || filters.objId || filters.responsavel || kw) && !eixoHasMatch) return;
    rows.push({ id: eixo.id, level: 0, type: 'eixo', label: eixo.nome, count: eixo.comites.length, expanded: !!expanded[eixo.id] });
    if (!expanded[eixo.id]) return;
    comitesVisible.forEach(comite => {
      const objVisible = comite.objetivos.filter(o => !filters.objId || filters.objId === o.id);
      const comiteHasMatch = objVisible.some(o => o.krs.some(krPassesFilters));
      if ((filters.objId || filters.responsavel || kw) && !comiteHasMatch) return;
      rows.push({ id: comite.id, level: 1, type: 'comite', label: comite.nome, count: comite.objetivos.length, expanded: !!expanded[comite.id] });
      if (!expanded[comite.id]) return;
      objVisible.forEach(obj => {
        const krsVisible = obj.krs.filter(krPassesFilters);
        if ((filters.responsavel || kw) && krsVisible.length === 0) return;
        rows.push({ id: obj.id, level: 2, type: 'objetivo', label: obj.nome, count: obj.krs.length, expanded: !!expanded[obj.id] });
        if (!expanded[obj.id]) return;
        krsVisible.forEach(kr => {
          const itsForResp = filters.responsavel ? kr.iniciativas.filter(it => it.responsaveis.includes(filters.responsavel)) : kr.iniciativas;
          rows.push({ id: kr.id, level: 3, type: 'kr', label: kr.label, count: itsForResp.length, expanded: !!expanded[kr.id], krRef: kr });
          if (!expanded[kr.id]) return;
          if (kr.metaSistemica) rows.push({ id: kr.id + '.meta', level: 4, type: 'meta-sistemica', label: `Meta sistêmica: ${kr.metaSistemica}`, noToggle: true });
          itsForResp.forEach(it => {
            rows.push({ id: it.id, level: 4, type: 'iniciativa', label: it.descricao || it.codigo || 'Iniciativa', count: 0, expanded: !!expanded[it.id], itRef: it, hasDetail: true });
            if (!expanded[it.id]) return;
            if (it.resultado) rows.push({ id: it.id + '.r', level: 5, type: 'detail', label: `Resultado Estratégico: ${it.resultado}`, noToggle: true });
            if (it.metaIndividual) rows.push({ id: it.id + '.m', level: 5, type: 'detail', label: `Meta Individual: ${it.metaIndividual}`, noToggle: true });
            if (it.responsaveis.length) rows.push({ id: it.id + '.p', level: 5, type: 'responsavel-row', label: it.responsaveis.join(', '), noToggle: true, responsaveis: it.responsaveis });
          });
        });
      });
    });
  });
  return rows;
}
window.IEL_MODEL = { buildModel, flattenTree };
