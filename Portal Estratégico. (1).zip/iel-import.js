// Client-side .xlsx parser + ETL: turns an uploaded workbook into the same
// Eixo -> Comitê -> Objetivo -> KR -> Iniciativa hierarchy shape as iel-data.js.

function readUint32(data, off) { return data[off] | (data[off + 1] << 8) | (data[off + 2] << 16) | (data[off + 3] << 24); }
function readUint16(data, off) { return data[off] | (data[off + 1] << 8); }

async function inflateRaw(bytes) {
  const ds = new DecompressionStream('deflate-raw');
  const stream = new Blob([bytes]).stream().pipeThrough(ds);
  const buf = await new Response(stream).arrayBuffer();
  return new Uint8Array(buf);
}

// Reads the Central Directory (authoritative sizes/offsets, unlike local headers which can be
// zeroed out when a producer streams entries with a trailing data descriptor).
function findEndOfCentralDir(data) {
  const sig = 0x06054b50;
  const maxBack = Math.min(data.length, 65557); // 22 (EOCD) + max 65535 comment
  for (let i = data.length - 22; i >= data.length - maxBack && i >= 0; i--) {
    if (readUint32(data, i) === sig) return i;
  }
  return -1;
}

async function unzip(data) {
  const files = {};
  const eocdOff = findEndOfCentralDir(data);
  if (eocdOff === -1) throw new Error('Arquivo .xlsx inválido (fim do índice ZIP não encontrado).');
  const cdEntries = readUint16(data, eocdOff + 10);
  const cdOffset = readUint32(data, eocdOff + 16);

  let off = cdOffset;
  const entries = [];
  for (let i = 0; i < cdEntries; i++) {
    const sig = readUint32(data, off);
    if (sig !== 0x02014b50) break;
    const method = readUint16(data, off + 10);
    const compSize = readUint32(data, off + 20);
    const nameLen = readUint16(data, off + 28);
    const extraLen = readUint16(data, off + 30);
    const commentLen = readUint16(data, off + 32);
    const localHeaderOffset = readUint32(data, off + 42);
    const name = new TextDecoder().decode(data.slice(off + 46, off + 46 + nameLen));
    entries.push({ name, method, compSize, localHeaderOffset });
    off += 46 + nameLen + extraLen + commentLen;
  }

  for (const entry of entries) {
    const lh = entry.localHeaderOffset;
    const lNameLen = readUint16(data, lh + 26);
    const lExtraLen = readUint16(data, lh + 28);
    const dataStart = lh + 30 + lNameLen + lExtraLen;
    const compData = data.slice(dataStart, dataStart + entry.compSize);
    files[entry.name] = { method: entry.method, compData };
  }

  const texts = {};
  for (const name of Object.keys(files)) {
    const f = files[name];
    const bytes = f.method === 0 ? f.compData : await inflateRaw(f.compData);
    texts[name] = new TextDecoder('utf-8').decode(bytes);
  }
  return texts;
}

function colToIndex(ref) {
  const m = ref.match(/^([A-Z]+)/)[1];
  let n = 0;
  for (const c of m) n = n * 26 + (c.charCodeAt(0) - 64);
  return n - 1;
}

function parseSheetTable(sharedStringsXml, sheetXml) {
  const parser = new DOMParser();
  const ssDoc = parser.parseFromString(sharedStringsXml || '<sst/>', 'text/xml');
  const sharedStrings = Array.from(ssDoc.getElementsByTagName('si')).map(si => Array.from(si.getElementsByTagName('t')).map(t => t.textContent).join(''));
  const sheetDoc = parser.parseFromString(sheetXml, 'text/xml');
  const rows = Array.from(sheetDoc.getElementsByTagName('row'));
  const table = [];
  for (const row of rows) {
    const cells = Array.from(row.getElementsByTagName('c'));
    const rowData = [];
    for (const c of cells) {
      const ref = c.getAttribute('r');
      const idx = colToIndex(ref);
      const t = c.getAttribute('t');
      const vNode = c.getElementsByTagName('v')[0];
      let val = vNode ? vNode.textContent : '';
      if (t === 's') val = sharedStrings[parseInt(val, 10)];
      else if (t === 'inlineStr') { const isNode = c.getElementsByTagName('is')[0]; val = isNode ? isNode.textContent : ''; }
      rowData[idx] = val;
    }
    table.push(rowData);
  }
  return table;
}

function splitLines(s) { if (!s) return []; return String(s).split('\n').map(x => x.trim()).filter(Boolean); }
function extractCode(line) {
  // tolerates stray spaces in the source around dots, e.g. "2.1. 4" meaning "2.1.4"
  const m = line.match(/^(\d+(?:\s*\.\s*\d+)+)/);
  return m ? m[1].replace(/\s+/g, '') : null;
}
function stripCode(line, code) {
  // code was normalized (spaces removed); re-find its actual (possibly spaced) span in the line
  const m = line.match(/^\d+(?:\s*\.\s*\d+)+/);
  const rest = m ? line.slice(m[0].length) : line.slice(line.indexOf(code) + code.length);
  return rest.replace(/^[.\s:\-–]+/, '').trim();
}
function codeVariants(code) { const p = code.split('.'); const v = []; for (let i = p.length; i >= 2; i--) v.push(p.slice(0, i).join('.')); return v; }
function buildKeyedMap(lines) {
  const map = {}; const uncoded = [];
  for (const l of lines) { const c = extractCode(l); if (c) { (map[c] = map[c] || []).push(stripCode(l, c)); } else uncoded.push(l); }
  return { map, uncoded };
}

function buildHierarchyFromTable(table) {
  const rows = table.slice(2); // skip blank spacer row + header row, matching source layout
  let eixo = '', comite = '', objetivo = '';
  const eixos = {}; const eixoOrder = [];

  for (const row of rows) {
    const rEixo = row[1], rComite = row[2], rObjetivo = row[3], rKR = row[4], rMeta = row[5], rInic = row[6], rResult = row[7], rResultAnt = row[8], rMetaInd = row[9], rResp = row[10];
    if (rEixo) eixo = rEixo;
    if (rComite) comite = rComite;
    if (rObjetivo) objetivo = rObjetivo;
    if (!eixo) continue;

    if (!eixos[eixo]) { eixos[eixo] = { nome: eixo, comites: {}, comiteOrder: [] }; eixoOrder.push(eixo); }
    const eixoObj = eixos[eixo];
    if (!eixoObj.comites[comite]) { eixoObj.comites[comite] = { nome: comite, objetivos: {}, objOrder: [] }; eixoObj.comiteOrder.push(comite); }
    const comiteObj = eixoObj.comites[comite];
    if (!comiteObj.objetivos[objetivo]) { comiteObj.objetivos[objetivo] = { nome: objetivo, krs: [] }; comiteObj.objOrder.push(objetivo); }
    const objetivoObj = comiteObj.objetivos[objetivo];

    if (!rKR) continue;

    const inicMap = buildKeyedMap(splitLines(rInic));
    const resultMap = buildKeyedMap(splitLines(rResult));
    const metaMap = buildKeyedMap(splitLines(rMetaInd));
    const respMap = buildKeyedMap(splitLines(rResp));

    // Resultado Estratégico entries as mapped directly in column H, independent of whether
    // they get matched to a specific iniciativa code — the count/list source of truth.
    const resultadosColH = splitLines(rResult).map(l => { const c = extractCode(l); return c ? stripCode(l, c) : l; }).filter(Boolean);

    function lookup(map, code) {
  for (const v of codeVariants(code)) {
    const arr = map[v];
    // shared/inherited entries (a single line covering several sub-codes, e.g. "9.1.2" also
    // covering "9.1.2.1") are peeked, not consumed; only distribute (shift) when a code has
    // more than one distinct entry of its own.
    if (arr && arr.length) return arr.length > 1 ? arr.shift() : arr[0];
  }
  return null;
}

// Responsável is special: several people are often listed under the SAME exact code (joint
// ownership, e.g. "8.1.1 Gerente..." + "8.1.1 Hugo Agra"). When there's only one iniciativa
// for that code, credit all of them (joined) instead of picking just the first. Only
// distributes one-per-iniciativa (old behavior) when the code itself repeats across iniciativas.
function lookupResp(map, code, iniciativaCountForCode) {
  const variants = codeVariants(code);
  const exact = variants[0];
  const arr = map[exact];
  if (arr && arr.length) {
    if (iniciativaCountForCode === 1) { const joined = arr.join('; '); map[exact] = []; return joined; }
    return arr.length > 1 ? arr.shift() : arr[0];
  }
  for (let i = 1; i < variants.length; i++) {
    const parr = map[variants[i]];
    if (parr && parr.length) return parr.length > 1 ? parr.shift() : parr[0];
  }
  return null;
}

    const iniciativas = [];
    for (const code of Object.keys(inicMap.map)) {
      const countForCode = inicMap.map[code].length;
      for (const desc of inicMap.map[code]) {
        iniciativas.push({ codigo: code, descricao: desc, resultado: lookup(resultMap.map, code), metaIndividual: lookup(metaMap.map, code), responsavel: lookupResp(respMap.map, code, countForCode) });
      }
    }
    const maxUncoded = Math.max(inicMap.uncoded.length, resultMap.uncoded.length, metaMap.uncoded.length, respMap.uncoded.length);
    for (let i = 0; i < maxUncoded; i++) {
      if (!inicMap.uncoded[i] && !resultMap.uncoded[i] && !metaMap.uncoded[i] && !respMap.uncoded[i]) continue;
      iniciativas.push({ codigo: null, descricao: inicMap.uncoded[i] || null, resultado: resultMap.uncoded[i] || null, metaIndividual: metaMap.uncoded[i] || null, responsavel: respMap.uncoded[i] || null });
    }

    objetivoObj.krs.push({
      label: rKR,
      metaSistemica: (rMeta && String(rMeta).trim() !== '-') ? String(rMeta).trim() : null,
      resultadoAnteriorRaw: rResultAnt ? String(rResultAnt).trim() : null,
      iniciativas,
      resultadosColH,
    });
  }

  return eixoOrder.map(eName => {
    const e = eixos[eName];
    return { nome: eName, comites: e.comiteOrder.map(cName => { const c = e.comites[cName]; return { nome: cName, objetivos: c.objOrder.map(oName => c.objetivos[oName]) }; }) };
  });
}

async function parseXlsxFile(file) {
  const buf = await file.arrayBuffer();
  const data = new Uint8Array(buf);
  const texts = await unzip(data);
  const sheetName = Object.keys(texts).find(n => /^xl\/worksheets\/sheet1\.xml$/.test(n)) || Object.keys(texts).find(n => /^xl\/worksheets\/sheet\d+\.xml$/.test(n));
  if (!sheetName) throw new Error('Nenhuma planilha encontrada no arquivo.');
  const table = parseSheetTable(texts['xl/sharedStrings.xml'], texts[sheetName]);
  const hierarchy = buildHierarchyFromTable(table);
  if (!hierarchy.length) throw new Error('Não foi possível reconhecer as colunas esperadas na planilha.');
  return hierarchy;
}
window.IEL_IMPORT = { parseXlsxFile };
